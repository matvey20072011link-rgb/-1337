package net.yourname.totemcounter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.item.Items;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class TotemCounter implements ModInitializer {

    private static final String OBJECTIVE_NAME = "totem_count";
    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(this::setupScoreboard);
        ServerTickEvents.END_SERVER_TICK.register(this::onTick);
    }

    private void setupScoreboard(MinecraftServer server) {
        Scoreboard scoreboard = server.getScoreboard();
        ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVE_NAME);

        if (objective == null) {
            objective = scoreboard.addObjective(
                    OBJECTIVE_NAME,
                    ScoreboardCriterion.DUMMY,
                    Text.literal("Тотемы"),
                    ScoreboardCriterion.RenderType.INTEGER,
                    true,
                    null
            );
        }
        scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.BELOW_NAME, objective);
    }

    private void onTick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter % 10 != 0) return;

        Scoreboard scoreboard = server.getScoreboard();
        ScoreboardObjective objective = scoreboard.getNullableObjective(OBJECTIVE_NAME);
        
        if (objective == null) return;

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            int totems = countTotems(player);
            ScoreAccess scoreAccess = scoreboard.getOrCreateScore(player, objective);
            scoreAccess.setScore(totems);
        }
    }

    private int countTotems(ServerPlayerEntity player) {
        int count = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                count += player.getInventory().getStack(i).getCount();
            }
        }
        return count;
    }
}
